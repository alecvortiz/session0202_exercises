require 'test_helper'

class SolutionsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
