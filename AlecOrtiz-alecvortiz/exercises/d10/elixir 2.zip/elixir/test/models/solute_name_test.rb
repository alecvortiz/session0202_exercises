require 'test_helper'

class SoluteNameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
