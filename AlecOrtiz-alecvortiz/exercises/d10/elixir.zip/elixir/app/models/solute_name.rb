class SoluteName < ActiveRecord::Base
	belongs_to :solution
end
